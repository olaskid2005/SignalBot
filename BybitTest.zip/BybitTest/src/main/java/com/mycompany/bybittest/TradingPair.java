/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class TradingPair 
{
    String symbol;
    double stepSize;

    public TradingPair(String symbol, double stepSize)
    {
        this.symbol = symbol;
        this.stepSize = stepSize;
    }

    public String getSymbol()
    {
        return symbol;
    }

    public double getStepSize()
    {
        return stepSize;
    }
    
}
