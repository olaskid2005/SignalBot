/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// FundingAwareFlipStrategy.java
import java.util.*;

public class FundingAwareFlipStrategy implements Strategy {
    // Uses premiumRate aggregated in premiumIndexKlines (per-minute funding indicator)
    double premiumThreshold; // e.g., 0.001 (0.1%)
    private final double riskUsd;
    private final double leverage;
    private TradingPair pair;

    public FundingAwareFlipStrategy(double riskUsd, double leverage, TradingPair pair)
    {
        this.riskUsd = riskUsd;
        this.leverage = leverage;
        this.pair = pair;
    }

    

    @Override
    public TradeSignal evaluate(List<ProcessedCandle> candles) {
        int n = candles.size();
        if (n < 3)
        {
            System.out.println("fafs null");
            return null;
        }
        // look at recent premium rates (most recent)
        double prem = candles.get(n-1).pipkClose();
        double prev = candles.get(n-2).pipkClose();
        double price = candles.get(n-1).kClose();
        if (prev < premiumThreshold && prem >= premiumThreshold) {
            // premium became positive above threshold -> shorts pay longs, long benefits?  
            // If premium positive, often longs pay shorts or shorts pay longs depending on definition.
            // Here we define: premium>0 means longs pay shorts -> short earns funding -> open short to capture funding.
            double notional = riskUsd * leverage; double qty = notional / price;
            double tp = price * (1 - 0.002); // small mean exit
            double sl = price * (1 + 0.005);
            System.out.println("fafs evaluated: sell");
            return new TradeSignal(TradeSignal.Side.SELL, roundQty(qty), tp, sl, "MARKET", 0.6, "Funding flip short");
        }
        if (prev > -premiumThreshold && prem <= -premiumThreshold) {
            // premium went strongly negative -> open long
            double notional = riskUsd * leverage; double qty = notional / price;
            double tp = price * (1 + 0.002);
            double sl = price * (1 - 0.005);
            System.out.println("fafs evaluated: buy");
            return new TradeSignal(TradeSignal.Side.BUY, roundQty(qty), tp, sl, "MARKET", 0.6, "Funding flip long");
        }
        return null;
    }
    private double roundQty(double q)
    { 
        return Math.floor(q / pair.getStepSize()) * pair.getStepSize();    
    }
    @Override public String name(){ return "FundingAwareFlip"; }
    
    public void updatePremiumThreshold(List<ProcessedCandle> candles) {
        if (candles == null || candles.isEmpty()) {
            // nothing to compute — keep existing premiumThreshold
            return;
        }

        // collect absolute premium rates (ignore NaN/Non-finite)
        double[] vals = new double[candles.size()];
        int cnt = 0;
        for (int i = 0; i < candles.size(); i++) {
            double p = candles.get(i).pipkClose(); // change if your accessor is different
            if (Double.isFinite(p)) {
                vals[cnt++] = Math.abs(p);
            }
        }

        // if no valid values found -> keep previous threshold and exit
        if (cnt == 0) {
            return;
        }

        // shrink array to actual count (if some were invalid)
        if (cnt < vals.length) vals = Arrays.copyOf(vals, cnt);

        // sort ascending
        Arrays.sort(vals);

        // percentile to use (0.99 = 99th percentile)
        double p = 0.99;
        double threshold;

        // compute percentile using (N+1)*p method with linear interpolation
        int n = vals.length;
        double pos = p * (n + 1);
        if (pos <= 1) {
            threshold = vals[0];
        } else if (pos >= n) {
            threshold = vals[n - 1];
        } else {
            int lower = (int) Math.floor(pos);
            int upper = lower + 1;
            double lowerVal = vals[lower - 1];
            double upperVal = vals[upper - 1];
            double frac = pos - lower;
            threshold = lowerVal + frac * (upperVal - lowerVal);
        }

        // enforce a small floor to avoid triggering on micro-noise
        double minFloor = 0.0001; // 0.01% default minimum
        if (threshold < minFloor) threshold = minFloor;

        // update the field (in-place change)
        premiumThreshold = threshold;
        System.out.println("premiumThreshold updated "+ premiumThreshold);
    }
}
