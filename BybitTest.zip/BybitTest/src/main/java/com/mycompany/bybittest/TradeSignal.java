/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// TradeSignal.java -- simple signal container
public class TradeSignal {
    public enum Side {BUY, SELL}
    public final Side side;
    public final double qty; // base currency / contract qty
    public final double tpPrice; // take profit price (0 if none)
    public final double slPrice; // stop loss price (0 if none)
    public final String orderType; // "MARKET" or "LIMIT"
    public final double confidence; // 0..1
    public final String reason;

    public TradeSignal(Side side, double qty, double tpPrice, double slPrice, String orderType, double confidence, String reason) {
        this.side = side; this.qty = qty; this.tpPrice = tpPrice; this.slPrice = slPrice;
        this.orderType = orderType; this.confidence = confidence; this.reason = reason;
    }

    public Side getSide() {
        return side;
    }

    public double getQty() {
        return qty;
    }

    public double getTpPrice() {
        return tpPrice;
    }

    public double getSlPrice() {
        return slPrice;
    }

    public String getOrderType() {
        return orderType;
    }

    public double getConfidence() {
        return confidence;
    }

    public String getReason() {
        return reason;
    }
    public String toString(){
        return String.format("Signal[%s qty=%.8f tp=%.6f sl=%.6f type=%s conf=%.2f reason=%s]",
            side, qty, tpPrice, slPrice, orderType, confidence, reason);
    }
}
