/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class Kline {
    private long startTime;
    private double open;
    private double high;
    private double low;
    private double close;
    private double volume;
    private double turnover;

    public Kline(long startTime, double open, double high, double low,
                 double close, double volume, double turnover) {
        this.startTime = startTime;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
        this.turnover = turnover;
    }

    public long getStartTime() {
        return startTime;
    }

    public double getOpen() {
        return open;
    }

    public double getHigh() {
        return high;
    }

    public double getLow() {
        return low;
    }

    public double getClose() {
        return close;
    }

    public double getVolume() {
        return volume;
    }

    public double getTurnover() {
        return turnover;
    }

    @Override
    public String toString() {
        return "Kline{" + "startTime=" + startTime + ", open=" + open + ", high=" + high + ", low=" + low + ", close=" + close + ", volume=" + volume + ", turnover=" + turnover + '}';
    }

    
}
