/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

import com.bybit.api.client.config.BybitApiConfig;
import com.bybit.api.client.domain.CategoryType;
import com.bybit.api.client.domain.TradeOrderType;
import com.bybit.api.client.domain.trade.Side;
import com.bybit.api.client.domain.trade.request.TradeOrderRequest;
import com.bybit.api.client.service.BybitApiClientFactory;
/**
 *
 * @author Ola
 */

public class PlaceOrder {
    
    public void marketOrder(String symbol, String side, String qty, String takeProfit, String stopLoss)
    {
        var client = BybitApiClientFactory.newInstance("WBE3jQ7mPiKP6vZCO0", "2MXE1jz3hMdBpXlRFDZvDxhxTvYQs656eo9K", BybitApiConfig.DEMO_TRADING_DOMAIN).newTradeRestClient();
        
        if(side.equals("SELL"))
        {
            var newOrderRequest1 = TradeOrderRequest.builder().category(CategoryType.LINEAR).symbol(symbol).side(Side.SELL).orderType(TradeOrderType.MARKET).qty(qty).takeProfit(takeProfit).stopLoss(stopLoss).build();
            var newOrder1 = client.createOrder(newOrderRequest1);
            System.out.println(newOrder1);
        }
        
        if(side.equals("BUY"))
        {
            var newOrderRequest1 = TradeOrderRequest.builder().category(CategoryType.LINEAR).symbol(symbol).side(Side.BUY).orderType(TradeOrderType.MARKET).qty(qty).takeProfit(takeProfit).stopLoss(stopLoss).build();
            var newOrder1 = client.createOrder(newOrderRequest1);
            System.out.println(newOrder1);
        }
        
    }
    
}
