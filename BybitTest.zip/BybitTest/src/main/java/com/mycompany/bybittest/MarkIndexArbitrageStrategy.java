/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// MarkIndexArbitrageStrategy.java
import java.util.*;

public class MarkIndexArbitrageStrategy implements Strategy {
    double spreadThreshold; // absolute price difference to act on
    private final double riskUsd;
    private final double leverage;
    private TradingPair pair;

    public MarkIndexArbitrageStrategy(double riskUsd, double leverage, TradingPair pair)
    {
        this.riskUsd = riskUsd;
        this.leverage = leverage;
        this.pair = pair;
    }

    @Override
    public TradeSignal evaluate(List<ProcessedCandle> candles) {
        int n = candles.size();
        if (n < 2)
        {
            System.out.println("mias null");
            return null;
        }
        double spread = candles.get(n-1).mpkClose()- candles.get(n-1).ipkClose();
        double price = candles.get(n-1).kClose();
        if (Math.abs(spread) < spreadThreshold) return null;
        double notional = riskUsd * leverage; double qty = notional / price;
        if (spread > spreadThreshold) {
            // mark >> index: expect convergence -> short mark/long index -> open short on underlying (simplified)
            double tp = price - Math.abs(spread) * 0.5;
            double sl = price + Math.abs(spread) * 0.8;
            System.out.println("mias evaluated: sell");
            return new TradeSignal(TradeSignal.Side.SELL, roundQty(qty), tp, sl, "MARKET", 0.65, "Mark>Index arb");
        } else {
            // mark << index
            double tp = price + Math.abs(spread) * 0.5;
            double sl = price - Math.abs(spread) * 0.8;
            System.out.println("mias evaluated: buy");
            return new TradeSignal(TradeSignal.Side.BUY, roundQty(qty), tp, sl, "MARKET", 0.65, "Index>Mark arb");
        }
    }
    private double roundQty(double q)
    { 
        return Math.floor(q / pair.getStepSize()) * pair.getStepSize();
    }
    @Override public String name(){ return "MarkIndexArbitrage"; }
    
    
    public void updateSpreadThreshold(List<ProcessedCandle> candles) {
    // collect all spreads (mark - index)
    double[] spreads = new double[candles.size()];
    for (int i = 0; i < candles.size(); i++) {
        spreads[i] = candles.get(i).mpkClose() - candles.get(i).ipkClose();
    }

    // compute mean
    double sum = 0;
    for (double s : spreads) sum += s;
    double mean = sum / spreads.length;

    // compute variance
    double varSum = 0;
    for (double s : spreads) varSum += Math.pow(s - mean, 2);
    double variance = varSum / spreads.length;

    // std deviation
    double std = Math.sqrt(variance);

    // threshold rule (2 × std is common)
    spreadThreshold =  2 * std;
    System.out.println("SpreadThreshold updated "+spreadThreshold);
}

}
