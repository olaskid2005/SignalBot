/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class IndexPriceKline {
    private long ipkStartTime;
    private double ipkOpen;
    private double ipkHigh;
    private double ipkLow;
    private double ipkClose;

    public IndexPriceKline(long ipkStartTime, double ipkOpen, double ipkHigh, double ipkLow, double ipkClose) {
        this.ipkStartTime = ipkStartTime;
        this.ipkOpen = ipkOpen;
        this.ipkHigh = ipkHigh;
        this.ipkLow = ipkLow;
        this.ipkClose = ipkClose;
    }

    public long getIpkStartTime() {
        return ipkStartTime;
    }

    public double getIpkOpen() {
        return ipkOpen;
    }

    public double getIpkHigh() {
        return ipkHigh;
    }

    public double getIpkLow() {
        return ipkLow;
    }

    public double getIpkClose() {
        return ipkClose;
    }

    @Override
    public String toString() {
        return "IndexPriceKline{" + "ipkStartTime=" + ipkStartTime + ", ipkOpen=" + ipkOpen + ", ipkHigh=" + ipkHigh + ", ipkLow=" + ipkLow + ", ipkClose=" + ipkClose + '}';
    }
    
    
}
