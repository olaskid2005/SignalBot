/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// VwapMeanReversionStrategy.java
import java.util.*;

public class VwapMeanReversionStrategy implements Strategy {
    private final double zThreshold; // e.g., 1.0 meaning 1*rollingStd
    private final int lookbackStd; // window for std
    private final double tpPct;
    private final double slPct;
    private final double riskUsd;
    private final double leverage;
    private TradingPair pair;

    public VwapMeanReversionStrategy(double zThreshold, int lookbackStd, double tpPct, double slPct, double riskUsd, double leverage, TradingPair pair)
    {
        this.zThreshold = zThreshold;
        this.lookbackStd = lookbackStd;
        this.tpPct = tpPct;
        this.slPct = slPct;
        this.riskUsd = riskUsd;
        this.leverage = leverage;
        this.pair = pair;
    }

    @Override
    public TradeSignal evaluate(List<ProcessedCandle> candles) {
        int n = candles.size();
        if (n < lookbackStd + 2)
        {
            System.out.println("Lookback small");
            return null;
        }
        double[] closes = Indicators.closes(candles);
        double[] vwap = Indicators.vwap(candles);
        double[] diff = new double[n];
        for (int i=0;i<n;i++) diff[i] = (closes[i] - vwap[i]);
        double[] stds = Indicators.rollingStd(diff, lookbackStd);
        int i = n-1;
        double z = stds[i] == 0 ? 0 : diff[i] / stds[i];
        // if price is far below vwap -> long mean revert
        if (z <= -zThreshold) {
            double price = closes[i];
            double notional = riskUsd * leverage;
            double qty = notional / price;
            double tp = vwap[i]; // target vwap
            double sl = price - Math.abs(z)* (slPct * price); // scaled
            
            System.out.println("price is far below vwap: buy");
            return new TradeSignal(TradeSignal.Side.BUY, roundQty(qty), tp, sl, "MARKET", 0.7, "VWAP mean-revert long (z="+String.format("%.2f",z)+")");
        }
        // price far above vwap -> short
        if (z >= zThreshold) {
            double price = closes[i];
            double notional = riskUsd * leverage;
            double qty = notional / price;
            double tp = vwap[i];
            double sl = price + Math.abs(z) * (slPct * price);
            
            System.out.println("price far above vwap: sell");
            return new TradeSignal(TradeSignal.Side.SELL, roundQty(qty), tp, sl, "MARKET", 0.7, "VWAP mean-revert short (z="+String.format("%.2f",z)+")");
        }
        return null;
    }

    private double roundQty(double q)
    {
        return Math.floor(q / pair.getStepSize()) * pair.getStepSize();
    }
    @Override public String name(){ return "VWAP-MeanReversion"; }
}
