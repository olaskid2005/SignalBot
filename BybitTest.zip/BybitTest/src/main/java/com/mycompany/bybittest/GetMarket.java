/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

import com.bybit.api.client.domain.CategoryType;
import com.bybit.api.client.domain.market.MarketInterval;
import com.bybit.api.client.domain.market.request.MarketDataRequest;
import com.bybit.api.client.service.BybitApiClientFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Ola
 */
public class GetMarket {
    
    public List<Kline> getKlines(String symbol) {
    var client = BybitApiClientFactory.newInstance().newMarketDataRestClient(); // sync client
    var marketKLineRequest = MarketDataRequest.builder()
        .category(CategoryType.LINEAR)
        .symbol(symbol)
        .marketInterval(MarketInterval.ONE_MINUTE)
        .limit(200)
        .build();

    Map<String, Object> response = (Map<String, Object>) client.getMarketLinesData(marketKLineRequest);
    Map<String, Object> result = (Map<String, Object>) response.get("result");
    List<List<Object>> klineList = (List<List<Object>>) result.get("list");

    List<Kline> klines = new ArrayList<>();
    for (List<Object> item : klineList) {
        Kline k = new Kline(
            Long.parseLong(item.get(0).toString()),    // startTime
            Double.parseDouble(item.get(1).toString()),// open
            Double.parseDouble(item.get(2).toString()),// high
            Double.parseDouble(item.get(3).toString()),// low
            Double.parseDouble(item.get(4).toString()),// close
            Double.parseDouble(item.get(5).toString()),// volume
            Double.parseDouble(item.get(6).toString()) // turnover
        );
        klines.add(k);
    }
    System.out.println("klines data gotten" +symbol);

    return klines;
}
    public List<MarkPriceKline> getMpKlines(String symbol)
    {
        var client = BybitApiClientFactory.newInstance().newMarketDataRestClient();
        var marketKLineRequest = MarketDataRequest.builder()
        .category(CategoryType.LINEAR)
        .symbol(symbol)
        .marketInterval(MarketInterval.ONE_MINUTE)
        .limit(200)
        .build();
        
        Map<String, Object> response = (Map<String, Object>) client.getMarketPriceLinesData(marketKLineRequest);
        Map<String, Object> result = (Map<String, Object>) response.get("result");
        List<List<Object>> mpKlineList = (List<List<Object>>) result.get("list");
        
        List<MarkPriceKline> mpKlines = new ArrayList<>();
        for(List<Object> item: mpKlineList){
            MarkPriceKline k = new MarkPriceKline(
                    Long.parseLong(item.get(0).toString()),    // startTime
                        Double.parseDouble(item.get(1).toString()),// open
                        Double.parseDouble(item.get(2).toString()),// high
                        Double.parseDouble(item.get(3).toString()),// low
                       Double.parseDouble(item.get(4).toString())// close
            );
            mpKlines.add(k);
        }
        System.out.println("Mark price data gotten" +symbol);
        
        return mpKlines;
        
    }
    
    public List<IndexPriceKline> getIpKlines(String symbol)
    {
        var client = BybitApiClientFactory.newInstance().newMarketDataRestClient();
        var marketKLineRequest = MarketDataRequest.builder()
        .category(CategoryType.LINEAR)
        .symbol(symbol)
        .marketInterval(MarketInterval.ONE_MINUTE)
        .limit(200)
        .build();
        
        Map<String, Object> response = (Map<String, Object>) client.getIndexPriceLinesData(marketKLineRequest);
        Map<String, Object> result = (Map<String, Object>) response.get("result");
        List<List<Object>> ipKlineList = (List<List<Object>>) result.get("list");
        
        List<IndexPriceKline> ipKlines = new ArrayList<>();
        for(List<Object> item: ipKlineList){
            IndexPriceKline k = new IndexPriceKline(
                    Long.parseLong(item.get(0).toString()),    // startTime
                        Double.parseDouble(item.get(1).toString()),// open
                        Double.parseDouble(item.get(2).toString()),// high
                        Double.parseDouble(item.get(3).toString()),// low
                       Double.parseDouble(item.get(4).toString())// close
            );
            ipKlines.add(k);
        }
        System.out.println("Index price data gotten" +symbol);
        
        return ipKlines;
        
    }
    
    public List<PremiumIndexPriceKline> getPipKlines(String symbol)
    {
        var client = BybitApiClientFactory.newInstance().newMarketDataRestClient();
        var marketKLineRequest = MarketDataRequest.builder()
        .category(CategoryType.LINEAR)
        .symbol(symbol)
        .marketInterval(MarketInterval.ONE_MINUTE)
        .limit(200)
        .build();
        
        Map<String, Object> response = (Map<String, Object>) client.getPremiumIndexPriceLinesData(marketKLineRequest);
        Map<String, Object> result = (Map<String, Object>) response.get("result");
        List<List<Object>> pipKlineList = (List<List<Object>>) result.get("list");
        
        List<PremiumIndexPriceKline> pipKlines = new ArrayList<>();
        for(List<Object> item: pipKlineList){
            PremiumIndexPriceKline k = new PremiumIndexPriceKline(
                    Long.parseLong(item.get(0).toString()),    // startTime
                        Double.parseDouble(item.get(1).toString()),// open
                        Double.parseDouble(item.get(2).toString()),// high
                        Double.parseDouble(item.get(3).toString()),// low
                       Double.parseDouble(item.get(4).toString())// close
            );
            pipKlines.add(k);
        }
        System.out.println("Premium Index Price Gotten" +symbol);
        
        return pipKlines;
        
    }

}
