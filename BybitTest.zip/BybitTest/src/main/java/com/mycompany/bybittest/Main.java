/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class Main 
{
    public static void main(String[] args) 
    {
        TradingPair[] pairs = {
                               new TradingPair("BTCUSDT", 0.001),
                               new TradingPair("ETHUSDT", 0.01)
                               }; // add pairs here
        for (TradingPair pair : pairs) 
        {
            Thread t = new Thread(new ThreadRunner(pair));
            t.start();
        }
    
    }
}
