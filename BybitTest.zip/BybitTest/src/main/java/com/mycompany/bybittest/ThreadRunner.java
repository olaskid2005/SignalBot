/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ola
 */
class ThreadRunner implements Runnable {
    private final TradingPair pair;
    private volatile boolean running = true;

    ThreadRunner(TradingPair pair) { this.pair = pair; }

    @Override
    public void run() {
        
        GetMarket market = new GetMarket();
        
        EmaCrossoverStrategy ema = new EmaCrossoverStrategy(12, 26, 0.002, 0.0015, 5, 100, pair);
        VwapMeanReversionStrategy vwap = new VwapMeanReversionStrategy(1.2, 45, 0.002, 0.004, 5, 100, pair);
        VolatilityBreakoutStrategy vbs = new VolatilityBreakoutStrategy(14, 1.5, 5, 100, pair);
        FundingAwareFlipStrategy fafs = new FundingAwareFlipStrategy(5, 100, pair); // threshold tuned small for premium rates
        MarkIndexArbitrageStrategy mias = new MarkIndexArbitrageStrategy(5, 100, pair); // e.g. $20 spread
        
        PlaceOrder order = new PlaceOrder();
        while (running) {
            try {
                // 1) Fetch all needed market data for this pair (implement this)
                List<Kline>klines = market.getKlines(pair.getSymbol());
                List<MarkPriceKline>mpKlines = market.getMpKlines(pair.getSymbol());
                List<IndexPriceKline>ipKlines = market.getIpKlines(pair.getSymbol());
                List<PremiumIndexPriceKline>pipKlines = market.getPipKlines(pair.getSymbol());
                
                List<ProcessedCandle> processed = new ArrayList<>();

                int n = Math.min(
                    Math.min(klines.size(), mpKlines.size()),
                    Math.min(ipKlines.size(), pipKlines.size())
                );

                for (int i = 0; i < n; i++) {
                    Kline k = klines.get(i);
                    MarkPriceKline mp = mpKlines.get(i);
                    IndexPriceKline ip = ipKlines.get(i);
                    PremiumIndexPriceKline pip = pipKlines.get(i);

                    ProcessedCandle pc = new ProcessedCandle(k, mp, ip, pip);
                    processed.add(pc);
                }
                
                // 2) Ask strategy what to do (BUY, SELL, or NONE)
                mias.updateSpreadThreshold(processed);
                fafs.updatePremiumThreshold(processed);
                
                
                TradeSignal signal1 = ema.evaluate(processed);
                TradeSignal signal2 = vwap.evaluate(processed);
                TradeSignal signal3 = vbs.evaluate(processed);
                TradeSignal signal4 = fafs.evaluate(processed);
                TradeSignal signal5 = mias.evaluate(processed);
                
                

                // 3) If strategy says trade -> place the order (implement placeOrder)
                if(signal1 != null)
                {
                    System.out.println("Signal 1 not null");
                    
                    String side = signal1.getSide().toString();
                    String qty = String.valueOf(signal1.getQty());
                    String takeProfit = String.valueOf(signal1.getTpPrice());
                    String stopLoss = String.valueOf(signal1.getSlPrice());
                    
                    order.marketOrder(pair.getSymbol(), side, qty, takeProfit, stopLoss);
                }
                
                if(signal2 != null)
                {
                    System.out.println("Signal 2 not null");
                    String side = signal2.getSide().toString();
                    String qty = String.valueOf(signal2.getQty());
                    String takeProfit = String.valueOf(signal2.getTpPrice());
                    String stopLoss = String.valueOf(signal2.getSlPrice());
                    
                    order.marketOrder(pair.getSymbol(), side, qty, takeProfit, stopLoss);
                }
                if(signal3 != null)
                {
                    System.out.println("Signal 3 not null");
                    String side = signal3.getSide().toString();
                    String qty = String.valueOf(signal3.getQty());
                    String takeProfit = String.valueOf(signal3.getTpPrice());
                    String stopLoss = String.valueOf(signal3.getSlPrice());
                    
                    order.marketOrder(pair.getSymbol(), side, qty, takeProfit, stopLoss);
                }
                if(signal4 != null)
                {
                    System.out.println("Signal 4 not null");
                    String side = signal4.getSide().toString();
                    String qty = String.valueOf(signal4.getQty());
                    String takeProfit = String.valueOf(signal4.getTpPrice());
                    String stopLoss = String.valueOf(signal4.getSlPrice());
                    
                    order.marketOrder(pair.getSymbol(), side, qty, takeProfit, stopLoss);
                }
                if(signal5 != null)
                {
                    System.out.println("Signal 5 not null");
                    String side = signal5.getSide().toString();
                    String qty = String.valueOf(signal5.getQty());
                    String takeProfit = String.valueOf(signal5.getTpPrice());
                    String stopLoss = String.valueOf(signal5.getSlPrice());
                    
                    order.marketOrder(pair.getSymbol(), side, qty, takeProfit, stopLoss);
                }
                
                
                

                // 4) Sleep 1 minute before next cycle
                Thread.sleep(60_000L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                running = false;
            } catch (Exception e) {
                // log error, then continue next loop
                e.printStackTrace();
                try { Thread.sleep(10_000L); } catch (InterruptedException ignored) {}
            }
        }
    }
}