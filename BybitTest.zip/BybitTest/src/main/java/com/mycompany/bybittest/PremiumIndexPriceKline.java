/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class PremiumIndexPriceKline {
    private long pipkStartTime;
    private double pipkOpen;
    private double pipkHigh;
    private double pipkLow;
    private double pipkClose;

    public PremiumIndexPriceKline(long pipkStartTime, double pipkOpen, double pipkHigh, double pipkLow, double pipkClose) {
        this.pipkStartTime = pipkStartTime;
        this.pipkOpen = pipkOpen;
        this.pipkHigh = pipkHigh;
        this.pipkLow = pipkLow;
        this.pipkClose = pipkClose;
    }

    public long getPipkStartTime() {
        return pipkStartTime;
    }

    public double getPipkOpen() {
        return pipkOpen;
    }

    public double getPipkHigh() {
        return pipkHigh;
    }

    public double getPipkLow() {
        return pipkLow;
    }

    public double getPipkClose() {
        return pipkClose;
    }

    @Override
    public String toString() {
        return "PremiumIndexPriceKline{" + "pipkStartTime=" + pipkStartTime + ", pipkOpen=" + pipkOpen + ", pipkHigh=" + pipkHigh + ", pipkLow=" + pipkLow + ", pipkClose=" + pipkClose + '}';
    }
    
    
}
