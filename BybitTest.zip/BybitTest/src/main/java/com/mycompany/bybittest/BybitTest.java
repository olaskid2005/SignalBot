package com.mycompany.bybittest;
import com.bybit.api.client.config.BybitApiConfig;
import com.bybit.api.client.domain.trade.request.TradeOrderRequest;
import com.bybit.api.client.domain.*;
import com.bybit.api.client.domain.trade.*;
import com.bybit.api.client.domain.CategoryType;
import com.bybit.api.client.domain.market.*;
import com.bybit.api.client.domain.market.request.MarketDataRequest;
import com.bybit.api.client.service.BybitApiClientFactory;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * Examples on how to place orders, cancel them, amend them and query them
 */
public class BybitTest {
    public static void main(String[] args) throws InterruptedException {
        var client = BybitApiClientFactory.newInstance("WBE3jQ7mPiKP6vZCO0", "2MXE1jz3hMdBpXlRFDZvDxhxTvYQs656eo9K", BybitApiConfig.DEMO_TRADING_DOMAIN).newTradeRestClient();
//
//        // Get all real time orders
//        var openOrderRequest = TradeOrderRequest.builder().category(CategoryType.SPOT).build();
//        var allOpenOrders = client.getOpenOrders(openOrderRequest);
//        System.out.println(allOpenOrders);
//
//        // Create a new order
//        var newOrderRequest = TradeOrderRequest.builder().category(CategoryType.LINEAR).symbol("BTCUSDT").side(Side.BUY).orderType(TradeOrderType.MARKET).qty("0.005").build();
//        var newOrder = client.createOrder(newOrderRequest);
//        System.out.println(newOrder);
//        
//        //Get tickers
//        var client5 = BybitApiClientFactory.newInstance().newAsyncMarketDataRestClient();
//        var tickerReueqt = MarketDataRequest.builder().category(CategoryType.LINEAR).symbol("BTCUSDT").build();
//        client5.getMarketTickers(tickerReueqt, System.out::println);
        
//        var client2 = BybitApiClientFactory.newInstance().newAsyncPositionRestClient();
//        var setLeverageRequest1 = PositionDataRequest.builder().category(CategoryType.LINEAR).symbol("BTCUSDT").buyLeverage("100").sellLeverage("100").build();
//        client2.setPositionLeverage(setLeverageRequest1, System.out::println);
//
        // Create a new order
//        var newOrderRequest1 = TradeOrderRequest.builder().category(CategoryType.LINEAR).symbol("BTCUSDT").side(Side.SELL).orderType(TradeOrderType.MARKET).qty("0.005").build();
//        var newOrder1 = client.createOrder(newOrderRequest1);
//        System.out.println(newOrder1);
        
        while (true) 
        {
            var clients = BybitApiClientFactory.newInstance().newMarketDataRestClient();
            var marketKLineRequest = MarketDataRequest.builder().category(CategoryType.LINEAR).symbol("BTCUSDT").marketInterval(MarketInterval.ONE_MINUTE).limit(2).build();
            System.out.println(clients.getMarketLinesData(marketKLineRequest));
            Thread.sleep(60_000L);
        }
        
//
//        List<List<Object>> klineList = (List<List<Object>>) result.get("list");
//        System.out.println(klineList);
//        List<Kline> klines = new ArrayList<>();
//    
//        for (List<Object> item : klineList) {
//            Kline k = new Kline(
//                Long.parseLong(item.get(0).toString()),    // startTime
//                Double.parseDouble(item.get(1).toString()),// open
//                Double.parseDouble(item.get(2).toString()),// high
//                Double.parseDouble(item.get(3).toString()),// low
//                Double.parseDouble(item.get(4).toString()),// close
//                Double.parseDouble(item.get(5).toString()),// volume
//                Double.parseDouble(item.get(6).toString()) // turnover
//            );
//            System.out.println("item"+ item);
//            klines.add(k);
//        }
//
//        // ✅ Example usage
//        System.out.println("All Klines: " + klines);
//        System.out.println("Close prices:");
//        klines.forEach(k -> System.out.println(k.getClose()));
//        System.out.println("Latest close:");
//        System.out.println(klines.get(0).getClose());
//    
//      });
        
        
//        //TEST GETMARKET CLASS
//        GetMarket market = new GetMarket();
//        System.out.println(market.getKlines("BTCUSDT"));
//        System.out.println(market.getIpKlines("BTCUSDT"));
//        System.out.println(market.getMpKlines("BTCUSDT"));
//        System.out.println(market.getPipKlines("BTCUSDT"));
        
    }
}