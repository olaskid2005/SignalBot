/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// Indicators.java -- helper static methods
import java.util.*;
public class Indicators {

    // EMA computed iteratively from list of doubles (older -> newer)
    public static double[] ema(double[] values, int span) {
        double[] out = new double[values.length];
        double alpha = 2.0 / (span + 1.0);
        double prev = values[0];
        out[0] = prev;
        for (int i=1;i<values.length;i++){
            prev = alpha * values[i] + (1 - alpha) * prev;
            out[i] = prev;
        }
        System.out.println("atr indicator calculate "+ Arrays.toString(out));
        return out;
    }

    public static double[] rollingStd(double[] values, int window) {
        double[] out = new double[values.length];
        for (int i=0;i<values.length;i++){
            int start = Math.max(0, i - window + 1);
            double sum = 0, sum2 = 0;
            int n = 0;
            for (int j=start;j<=i;j++){
                double v = values[j]; sum += v; sum2 += v*v; n++;
            }
            double mean = sum / n;
            double var = (sum2 / n) - mean*mean;
            out[i] = var <= 0 ? 0 : Math.sqrt(var);
        }
        System.out.println("rollingStd indicator calculated "+ Arrays.toString(out));
        return out;
    }

    // ATR (simple moving average of True Range)
    public static double[] atr(List<ProcessedCandle> candles, int length) {
        int n = candles.size();
        double[] tr = new double[n];
        for (int i=0;i<n;i++){
            double h = candles.get(i).kHigh();
            double l = candles.get(i).kLow();
            double prevClose = i==0 ? candles.get(0).kClose(): candles.get(i-1).kClose();
            double v1 = h - l;
            double v2 = Math.abs(h - prevClose);
            double v3 = Math.abs(l - prevClose);
            tr[i] = Math.max(v1, Math.max(v2, v3));
        }
        double[] atr = new double[n];
        double sum = 0;
        for (int i=0;i<n;i++){
            sum += tr[i];
            if (i >= length) sum -= tr[i-length];
            atr[i] = sum / Math.min(i+1, length);
        }
        System.out.println("atr indicator calculated "+ Arrays.toString(atr));
        return atr;
    }

    // VWAP per candle: typical price * volume / volume -> same as typical price if 1-minute VWAP
    public static double[] vwap(List<ProcessedCandle> candles) {
        int n = candles.size();
        double[] v = new double[n];
        for (int i=0;i<n;i++){
            ProcessedCandle c = candles.get(i);
            double tp = (c.kHigh()+ c.kLow()+ c.kClose()) / 3.0;
            v[i] = tp; // since we have per-minute aggregated, treat vwap=typical price
        }
        System.out.println("vwap indicator calculated "+ Arrays.toString(v));
        return v;
    }

    // convenience helper to read close array
    public static double[] closes(List<ProcessedCandle> candles){
        int n=candles.size(); double[] out=new double[n];
        for(int i=0;i<n;i++) out[i] = candles.get(i).kClose();
        return out;
    }
}

