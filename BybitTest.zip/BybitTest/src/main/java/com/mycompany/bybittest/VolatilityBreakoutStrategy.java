/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// VolatilityBreakoutStrategy.java
import java.util.*;

public class VolatilityBreakoutStrategy implements Strategy {
    private final int atrLen;
    private final double atrMultiplier; // e.g., 1.5
    private final double riskUsd;
    private final double leverage;
    private TradingPair pair;

    public VolatilityBreakoutStrategy(int atrLen, double atrMultiplier, double riskUsd, double leverage, TradingPair pair)
    {
        this.atrLen = atrLen;
        this.atrMultiplier = atrMultiplier;
        this.riskUsd = riskUsd;
        this.leverage = leverage;
        this.pair = pair;
    }

    @Override
    public TradeSignal evaluate(List<ProcessedCandle> candles) {
        int n = candles.size();
        if (n < atrLen + 2)
        {
            System.out.println("vbs null");
            return null;
        }
        double[] atr = Indicators.atr(candles, atrLen);
        int i = n-1;
        double lastClose = candles.get(i).kClose();
        double prevClose = candles.get(i-1).kClose();
        double threshold = atr[i] * atrMultiplier;
        // breakout up
        if (lastClose > prevClose + threshold) {
            double price = lastClose;
            double notional = riskUsd * leverage;
            double qty = notional / price;
            double tp = price + threshold; // simple target
            double sl = price - threshold * 0.8;
            System.out.println("vbs evaluated: buy");
            return new TradeSignal(TradeSignal.Side.BUY, roundQty(qty), tp, sl, "MARKET", 0.75, "Vol breakout UP");
        }
        // breakout down
        if (lastClose < prevClose - threshold) {
            double price = lastClose;
            double notional = riskUsd * leverage;
            double qty = notional / price;
            double tp = price - threshold;
            double sl = price + threshold*0.8;
            System.out.println("vbs evaluated sell");
            return new TradeSignal(TradeSignal.Side.SELL, roundQty(qty), tp, sl, "MARKET", 0.75, "Vol breakout DOWN");
        }
        return null;
    }
    private double roundQty(double q)
    { 
        return Math.floor(q / pair.getStepSize()) * pair.getStepSize();
    }
    @Override public String name(){ return "VolatilityBreakout"; }
}
