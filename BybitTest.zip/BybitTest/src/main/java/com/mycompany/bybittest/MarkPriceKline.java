/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class MarkPriceKline {
    private long mpkStartTime;
    private double mpkOpen;
    private double mpkHigh;
    private double mpkLow;
    private double mpkClose;

    public MarkPriceKline(long mpkStartTime, double mpkOpen, double mpkHigh, double mpkLow, double mpkClose) {
        this.mpkStartTime = mpkStartTime;
        this.mpkOpen = mpkOpen;
        this.mpkHigh = mpkHigh;
        this.mpkLow = mpkLow;
        this.mpkClose = mpkClose;
    }

    public long getMpkStartTime() {
        return mpkStartTime;
    }

    public double getMpkOpen() {
        return mpkOpen;
    }

    public double getMpkHigh() {
        return mpkHigh;
    }

    public double getMpkLow() {
        return mpkLow;
    }

    public double getMpkClose() {
        return mpkClose;
    }

    @Override
    public String toString() {
        return "MarkPriceKline{" + "mpkStartTime=" + mpkStartTime + ", mpkOpen=" + mpkOpen + ", mpkHigh=" + mpkHigh + ", mpkLow=" + mpkLow + ", mpkClose=" + mpkClose + '}';
    }
    
    
    
}
