/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
public class ProcessedCandle {
    private final Kline k;
    private final MarkPriceKline mp;
    private final IndexPriceKline ip;
    private final PremiumIndexPriceKline pip;

    public ProcessedCandle(Kline k, MarkPriceKline mp, IndexPriceKline ip, PremiumIndexPriceKline pip) {
        this.k = k;
        this.mp = mp;
        this.ip = ip;
        this.pip = pip;
    }
    //KLINE
    public long kTime(){return k.getStartTime();}
    public double kOpen(){return k.getOpen();}
    public double kHigh(){return k.getHigh();}
    public double kLow(){return k.getLow();}
    public double kClose(){return k.getClose();}
    public double kVolume(){return k.getVolume();}
    public double kTurnOver(){return k.getTurnover();}
    //MARKPRICEKLINE
    public long mpkTime(){return mp.getMpkStartTime();}
    public double mpkOpen(){return mp.getMpkOpen();}
    public double mpkHigh(){return mp.getMpkHigh();}
    public double mpkLow(){return mp.getMpkLow();}
    public double mpkClose(){return mp.getMpkClose();}
    //INDEXPRICEKLINE
    public long ipkTime(){return ip.getIpkStartTime();}
    public double ipkOpen(){return ip.getIpkOpen();}
    public double ipkHigh(){return ip.getIpkHigh();}
    public double ipkLow(){return ip.getIpkLow();}
    public double ipkClose(){return ip.getIpkClose();}
    //PREMIUMINDEXKLINE
    public long pipkTime(){return pip.getPipkStartTime();}
    public double pipkOpen(){return pip.getPipkOpen();}
    public double pipkHigh(){return pip.getPipkHigh();}
    public double pipkLow(){return pip.getPipkLow();}
    public double pipkClose(){return pip.getPipkClose();}
}
