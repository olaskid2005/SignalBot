/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// EmaCrossoverStrategy.java -- momentum strategy
import java.util.*;

public class EmaCrossoverStrategy implements Strategy {
    private final int fast;
    private final int slow;
    private final double tpPct; // take profit relative to entry (e.g., 0.002 = 0.2%)
    private final double slPct;
    private final double riskPerTradeUsd; // e.g., 5
    private final double leverage; // e.g., 100
    private TradingPair pair;

    public EmaCrossoverStrategy(int fast, int slow, double tpPct, double slPct, double riskPerTradeUsd, double leverage, TradingPair pair)
    {
        this.fast = fast;
        this.slow = slow;
        this.tpPct = tpPct;
        this.slPct = slPct;
        this.riskPerTradeUsd = riskPerTradeUsd;
        this.leverage = leverage;
        this.pair = pair;
    }

    @Override
    public TradeSignal evaluate(List<ProcessedCandle> candles) {
        if (candles.size() < slow + 3){
            System.out.println("Too few candles");
            return null;
        }
        double[] closes = Indicators.closes(candles);
        double[] emaFast = Indicators.ema(closes, fast);
        double[] emaSlow = Indicators.ema(closes, slow);
        int i = closes.length - 1;
        int prev = i-1;
        // bullish crossover: fast crosses above slow
        if (emaFast[prev] <= emaSlow[prev] && emaFast[i] > emaSlow[i]) {
            double price = candles.get(i).kClose();
            double notional = riskPerTradeUsd * leverage;
            double qty = notional / price;
            double tp = price * (1 + tpPct);
            double sl = price * (1 - slPct);
            System.out.println("Bullish crossover");
            return new TradeSignal(TradeSignal.Side.BUY, roundQty(qty), tp, sl, "MARKET", 0.8, "EMA bullish crossover");
        }
        // bearish crossover
        if (emaFast[prev] >= emaSlow[prev] && emaFast[i] < emaSlow[i]) {
            double price = candles.get(i).kClose();
            double notional = riskPerTradeUsd * leverage;
            double qty = notional / price;
            double tp = price * (1 - tpPct);
            double sl = price * (1 + slPct);
            System.out.println("Bearish crossover");
            return new TradeSignal(TradeSignal.Side.SELL, roundQty(qty), tp, sl, "MARKET", 0.8, "EMA bearish crossover");
        }
        return null;
    }

    private double roundQty(double q){
        // basic rounding to 8 decimals; replace with instrument-specific step rounding
        return Math.floor(q / pair.getStepSize()) * pair.getStepSize();
    }

    @Override public String name(){ return "EMA-Crossover"; }
}
