/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.bybittest;

/**
 *
 * @author Ola
 */
// Strategy.java -- interface for strategies
import java.util.*;
public interface Strategy {
    // supply full history of processed candles (oldest->newest). Strategy should inspect last element for realtime.
    // returns Optional<TradeSignal> (empty if no trade)
    TradeSignal evaluate(List<ProcessedCandle> candles);
    String name();
}
